<?php
	$questoes = array(
		array("Depois de um assalto a um banco, quatro testemunhas deram quatro diferentes descriçôes do assaltante segundo quatro características, a saber: estatura, cor de olhos, tipo de cabelos e usar ou não bigode.
			Testemunha 1: “Ele é alto, olhos verdes, cabelos crespos e usa bigode.”
			Testemunha 2: “Ele é baixo, olhos azuis, cabelos crespos e usa bigode.”
			Testemunha 3: “Ele é de estatura mediana, olhos castanhos, cabelos lisos e usa bigode.”
			Testemunha 4: “Ele é alto, olhos negros, cabelos crespos e não usa bigode.”
			Cada testemunha descreveu corretamente uma e apenas uma das características do assaltante, e cada característica foi corretamente descrita por uma das testemunhas. Assim, o assaltante é:",
			"Baixo, olhos azuis, cabelos lisos e usa bigode.",
			"Alto, olhos azuis, cabelos lisos e usa bigode.",
			"Baixo, olhos verdes, cabelos lisos e não usa bigode.",
			"Estatura mediana, olhos verdes, cabelos crespos e não usa bigode."),
		array("Se os funcionários de certa empresa consomem, em média, a água de 2,4 garrafôes a cada 2 dias, quantos dias espera-se que eles levariam para consumir a água de 36 garrafôes, todos com a mesma capacidade do primeiro?",
			"28",
 			"30",
 			"35",
 			"36"),
		array("Um táxi inicia uma corrida marcando R$ 3,00 no taxímetro. A cada quilômetro rodado, o valor cobrado é de R$ 1,00. Se o valor total pago nesta corrida é de R$12,00, quantos quilômetros foram percorridos?",
			"8",
 			"10",
			"12",
 			"9"),
		array("Do preço de venda de um determinado produto, 25% correspondem a impostos e comissôes pagos pelo lojista. Do restante, 60% correspondem ao preço de custo desse produto. Se o preço de custo desse produto é de R$ 405,00, então, o seu preço de venda é igual a:",
			"R$ 540,00.",
			"R$ 675,00.",
 			"R$ 800,00.",
 			"R$ 900,00."),
	);
	$gabaritoOficial = array("C", "B", "D", "D");
?>